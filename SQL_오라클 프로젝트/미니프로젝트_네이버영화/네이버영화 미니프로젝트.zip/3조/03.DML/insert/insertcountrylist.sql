insert into z_countrylist values (1,'미국');
insert into z_countrylist values (2,'한국');
insert into z_countrylist values (3,'캐나다');
insert into z_countrylist values (4,'일본');
insert into z_countrylist values (5,'홍콩');
insert into z_countrylist values (6,'멕시코');
insert into z_countrylist values (7,'영국');
insert into z_countrylist values (8,'프랑스');
insert into z_countrylist values (9,'스페인');
insert into z_countrylist values (10,'카자흐스탄');

select * from z_countrylist;