insert into z_genrelist values (1,'판타지');
insert into z_genrelist values (2,'모험');
insert into z_genrelist values (3,'가족');
insert into z_genrelist values (4,'드라마');
insert into z_genrelist values (5,'액션');
insert into z_genrelist values (6,'스릴러');
insert into z_genrelist values (7,'코미디');
insert into z_genrelist values (8,'멜로/로맨스');
insert into z_genrelist values (9,'범죄');
insert into z_genrelist values (10,'느와르');
insert into z_genrelist values (11,'공포');
insert into z_genrelist values (12,'애니메이션');
insert into z_genrelist values (13,'SF');
insert into z_genrelist values (14,'다큐멘터리');
insert into z_genrelist values (15,'전쟁');
insert into z_genrelist values (16,'미스터리');

select * from z_genrelist;