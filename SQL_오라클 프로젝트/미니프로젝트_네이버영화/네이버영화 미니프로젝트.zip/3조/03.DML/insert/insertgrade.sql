insert into z_grade values (1,'전체관람가');
insert into z_grade values (2,'12세 이상 관람가');
insert into z_grade values (3,'15세 이상 관람가');
insert into z_grade values (4,'청소년 관람불가');
insert into z_grade values (5,'제한상영가');
insert into z_grade values (6,'미정');

select * from z_grade;
