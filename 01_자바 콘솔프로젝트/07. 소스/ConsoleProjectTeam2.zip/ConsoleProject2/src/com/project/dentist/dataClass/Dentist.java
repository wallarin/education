package com.project.dentist.dataClass;

/**
 * 병원 정보를 저장하는 클래스입니다.
 * @author 고민지
 *
 */
public class Dentist {

	public static final String name = "바른치과";
	public static final String phoneNum = "02-3482-4632";
	public static final String address = "서울시 강남구 테헤란로 132";
	
}
