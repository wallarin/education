-- tblStuStop 교육생중도탈락 데이터

insert into tblStuStop(stustop_seq, stop_date, sugang_seq) values (	1	,	'2022-03-25'	,	217	);
insert into tblStuStop(stustop_seq, stop_date, sugang_seq) values (	2	,	'2022-03-30'	,	187	);
insert into tblStuStop(stustop_seq, stop_date, sugang_seq) values (	3	,	'2022-04-04'	,	181	);
insert into tblStuStop(stustop_seq, stop_date, sugang_seq) values (	4	,	'2022-04-12'	,	258	);
insert into tblStuStop(stustop_seq, stop_date, sugang_seq) values (	5	,	'2022-04-12'	,	277	);