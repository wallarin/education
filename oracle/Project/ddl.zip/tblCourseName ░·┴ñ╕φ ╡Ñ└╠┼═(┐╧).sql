-- tblCourseName 과정명 데이터

insert into tblCourseName(cname_seq, course_neme) values(1,'[스마트혼합훈련](디지털컨버전스)자바 기반 AWS 클라우드 활용 Full-Stack 개발자 양성 과정');
insert into tblCourseName(cname_seq, course_neme) values(2,'정보시스템구축)백엔드 응용 엔지니어 양성과정');
insert into tblCourseName(cname_seq, course_neme) values(3,'Java and Python 기반 응용SW 개발자 양성과정');
insert into tblCourseName(cname_seq, course_neme) values(4,'실무 프로젝트 기반 자바 and 빅데이터 개발자 양성과정');
insert into tblCourseName(cname_seq, course_neme) values(5,'SW 응용 엔지니어 양성과정');
insert into tblCourseName(cname_seq, course_neme) values(6,'(클라우드운영관리)소프트웨어 혼합 전문가 양성과정');
insert into tblCourseName(cname_seq, course_neme) values(7,'디지털 콘텐츠 융합백엔드 전문가 양성과정');
insert into tblCourseName(cname_seq, course_neme) values(8,'프론트엔드 혼합 개발자 양성과정');
insert into tblCourseName(cname_seq, course_neme) values(9,'(웹기반)소프트웨어 응용 전문가 양성과정');