-- tblAdmin 관리자 데이터

insert into tblAdmin (admin_seq, id, password) values(1,'admin1',2503);
insert into tblAdmin (admin_seq, id, password) values(2,'admin2',4535);
insert into tblAdmin (admin_seq, id, password) values(3,'admin3',2363);
insert into tblAdmin (admin_seq, id, password) values(4,'admin4',4562);