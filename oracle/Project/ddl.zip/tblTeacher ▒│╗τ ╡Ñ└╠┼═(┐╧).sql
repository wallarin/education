-- tblTeacher 교사 데이터

insert into tblTeacher (teacher_seq, t_name, t_password, t_tel) values (1,'최경하',2532102,'010-5285-3994');
insert into tblTeacher (teacher_seq, t_name, t_password, t_tel) values (2,'허예숙',2030422,'010-7467-2111');
insert into tblTeacher (teacher_seq, t_name, t_password, t_tel) values (3,'송유주',2142021,'010-6339-7148');
insert into tblTeacher (teacher_seq, t_name, t_password, t_tel) values (4,'강수현',1423023,'010-4912-4701');
insert into tblTeacher (teacher_seq, t_name, t_password, t_tel) values (5,'허태연',1728392,'010-5443-5830');
insert into tblTeacher (teacher_seq, t_name, t_password, t_tel) values (6,'추명원',1734222,'010-1932-1332');
insert into tblTeacher (teacher_seq, t_name, t_password, t_tel) values (7,'정우재',1545345,'010-2438-8474');
insert into tblTeacher (teacher_seq, t_name, t_password, t_tel) values (8,'이승은',1935465,'010-4630-7751');
insert into tblTeacher (teacher_seq, t_name, t_password, t_tel) values (9,'손윤자',2034953,'010-9374-5864');
insert into tblTeacher (teacher_seq, t_name, t_password, t_tel) values (10,'최진혁',1525343,'010-9705-7507');