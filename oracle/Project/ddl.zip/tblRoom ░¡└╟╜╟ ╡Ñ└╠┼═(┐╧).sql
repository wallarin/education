-- tblRoom 강의실 데이터

insert into tblRoom (room_seq, room_name, room_personel) values(1,'1강의실',30);
insert into tblRoom (room_seq, room_name, room_personel) values(2,'2강의실',30);
insert into tblRoom (room_seq, room_name, room_personel) values(3,'3강의실',30);
insert into tblRoom (room_seq, room_name, room_personel) values(4,'4강의실',26);
insert into tblRoom (room_seq, room_name, room_personel) values(5,'5강의실',26);
insert into tblRoom (room_seq, room_name, room_personel) values(6,'6강의실',26);